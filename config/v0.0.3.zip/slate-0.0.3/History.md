
0.0.3 / 2015-07-29
==================

  * Change PFDinDisplayPro-Regular to PFDinDisplayPro-Light.
  * Use the web fonts as a fallback for when system font is unavailable. 

0.0.2 / 2015-07-29
==================

  * Fix font imports.

0.0.1 / 2015-07-07
==================

  * Initial release
